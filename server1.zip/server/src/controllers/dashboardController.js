import Website from "../models/Website.js";
import Slider from "../models/Slider.js";
import Project from "../models/Project.js";
import Testimonial from "../models/Testimonial.js";
import Event from "../models/Event.js";
import TeamMember from "../models/TeamMember.js";
import Blog from "../models/Blog.js";
import ContactEnquiry from "../models/ContactEnquiry.js";
import AwardCertification from "../models/AwardCertification.js";
import { successResponse } from "../utils/apiResponse.js";

export const getDashboardCounts = async (req, res, next) => {
  try {
    const [
      totalWebsites,
      totalSliders,
      totalProjects,
      totalTestimonials,
      totalEvents,
      totalAwardsCertifications,
      totalTeamMembers,
      totalBlogs,
      totalContactEnquiries
    ] = await Promise.all([
      Website.countDocuments(),
      Slider.countDocuments(),
      Project.countDocuments(),
      Testimonial.countDocuments(),
      Event.countDocuments(),
      AwardCertification.countDocuments(),
      TeamMember.countDocuments(),
      Blog.countDocuments(),
      ContactEnquiry.countDocuments()
    ]);

    successResponse(res, "Dashboard counts fetched", {
      totalWebsites,
      totalSliders,
      totalProjects,
      totalTestimonials,
      totalEvents,
      totalAwardsCertifications,
      totalTeamMembers,
      totalBlogs,
      totalContactEnquiries
    });
  } catch (error) {
    next(error);
  }
};
