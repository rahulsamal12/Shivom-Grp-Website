export const WEBSITE_KEYS = ["group", "solar", "concrete", "enterprise"];

export const ACTIVE_STATUSES = ["active", "inactive"];

export const BLOG_STATUSES = ["draft", "published"];

export const CONTACT_STATUSES = ["new", "read", "replied", "closed"];

export const isValidWebsiteKey = (websiteKey) => WEBSITE_KEYS.includes(websiteKey);
