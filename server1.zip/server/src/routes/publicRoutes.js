import express from "express";
import {
  createContactEnquiry,
  getAwardCertificationBySlug,
  getBlogBySlug,
  getEventBySlug,
  getHome,
  getLandingSections,
  getPageBySlug,
  getProjectBySlug,
  getSliders,
  listBlogs,
  listAwardsCertifications,
  listEvents,
  listFeaturedAwardsCertifications,
  listFeaturedBlogs,
  listFeaturedProjects,
  listProjects,
  listTeam,
  listTestimonials
} from "../controllers/publicController.js";

const router = express.Router();

router.get("/:websiteKey/home", getHome);
router.get("/:websiteKey/sliders", getSliders);
router.get("/:websiteKey/pages/:slug", getPageBySlug);
router.get("/:websiteKey/landing-sections", getLandingSections);
router.get("/:websiteKey/projects", listProjects);
router.get("/:websiteKey/projects/featured", listFeaturedProjects);
router.get("/:websiteKey/projects/:slug", getProjectBySlug);
router.get("/:websiteKey/testimonials", listTestimonials);
router.get("/:websiteKey/events", listEvents);
router.get("/:websiteKey/events/:slug", getEventBySlug);
router.get("/:websiteKey/awards-certifications", listAwardsCertifications);
router.get("/:websiteKey/awards-certifications/featured", listFeaturedAwardsCertifications);
router.get("/:websiteKey/awards-certifications/:slug", getAwardCertificationBySlug);
router.get("/:websiteKey/team", listTeam);
router.get("/:websiteKey/blogs", listBlogs);
router.get("/:websiteKey/blogs/featured", listFeaturedBlogs);
router.get("/:websiteKey/blogs/:slug", getBlogBySlug);
router.post("/:websiteKey/contact", createContactEnquiry);

export default router;
