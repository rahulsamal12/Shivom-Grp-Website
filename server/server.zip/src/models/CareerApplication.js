import mongoose from "mongoose";
import { CAREER_APPLICATION_STATUSES, WEBSITE_KEYS } from "../utils/constants.js";

const careerApplicationSchema = new mongoose.Schema(
  {
    websiteKey: {
      type: String,
      enum: WEBSITE_KEYS,
      required: [true, "Website key is required"],
      index: true
    },
    careerId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Career",
      required: [true, "Career is required"],
      index: true
    },
    jobTitle: {
      type: String,
      required: [true, "Job title is required"],
      trim: true
    },
    applicantName: {
      type: String,
      required: [true, "Applicant name is required"],
      trim: true
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      trim: true,
      lowercase: true
    },
    phone: {
      type: String,
      trim: true
    },
    resume: {
      type: String,
      required: [true, "Resume is required"]
    },
    coverLetter: String,
    message: String,
    status: {
      type: String,
      enum: CAREER_APPLICATION_STATUSES,
      default: "new",
      index: true
    }
  },
  { timestamps: true }
);

export default mongoose.model("CareerApplication", careerApplicationSchema);
