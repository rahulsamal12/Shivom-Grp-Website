export const WEBSITE_KEYS = ["group", "solar", "concrete", "enterprise"];

export const ACTIVE_STATUSES = ["active", "inactive"];

export const BLOG_STATUSES = ["draft", "published"];

export const CONTACT_STATUSES = ["new", "read", "replied", "closed"];

export const JOB_TYPES = ["full-time", "part-time", "internship", "contract"];

export const CAREER_STATUSES = ["active", "inactive", "closed"];

export const CAREER_APPLICATION_STATUSES = ["new", "reviewed", "shortlisted", "rejected", "hired"];

export const AD_TYPES = ["popup", "top-banner", "bottom-banner", "sidebar", "browser-update"];

export const isValidWebsiteKey = (websiteKey) => WEBSITE_KEYS.includes(websiteKey);
